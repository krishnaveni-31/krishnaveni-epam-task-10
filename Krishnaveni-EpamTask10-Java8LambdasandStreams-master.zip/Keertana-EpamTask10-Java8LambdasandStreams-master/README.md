# Keertana-EpamTask10-Java8LambdasandStreams
Java 8 Lambdas and Streams
